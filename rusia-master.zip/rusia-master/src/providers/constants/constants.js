export const PROXY = 'http://moscutourgratis.com';
//# sourceMappingURL=constants.js.map